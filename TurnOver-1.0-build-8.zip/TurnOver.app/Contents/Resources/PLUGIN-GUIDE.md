# TurnOver plugin guide

This is the whole format for TurnOver plugins. It is written for people and for the AI assistants
most people will use to make plugins. If you are an AI: read this, then BRIEF.md in the brief folder,
and follow the steps there.

A plugin makes one application work better with TurnOver, a screen reader for the Mac. Today a plugin
is an **app profile**: two JSON files, no code. Profiles cannot run programs, read files, use the
internet, or touch any application other than the ones they name. That is deliberate (PLATFORM.md).

## The folder

```
my-plugin/
  manifest.json   who made it, and which application it is for
  profile.json    the rules
```

### manifest.json

```json
{
  "id": "bambustudio-profile",
  "name": "Bambu Studio",
  "version": "0.1",
  "author": "Oliver",
  "description": "Names the home page's buttons and adds keys for the main panels.",
  "apps": ["com.bambulab.bambu-studio"],
  "kind": "profile"
}
```

- `id`: one word, letters, digits and hyphens. Installing a plugin with the same id replaces it.
- `apps`: bundle identifiers. The rules apply in these applications and nowhere else.

### profile.json

Four lists, all optional:

```json
{
  "labels":  [ … names for elements that have none, or the wrong one … ],
  "keys":    [ … keys that press, focus or read an element, choose a menu item, or send keys … ],
  "watch":   [ … elements to read aloud when they change … ],
  "silence": [ … elements TurnOver should not announce … ]
}
```

## Matching elements

Every rule names elements with a **match**. Every field given must agree; leave out what you do
not need. Text comparisons ignore case, and `*` matches anything (`"Print*"`). A field that is
just `"*"` means "has one": `"help": "*"` matches elements that have a tooltip.

| Field | Matches | Example |
|---|---|---|
| `role` | The accessibility role, with or without AX | `"AXButton"`, `"button"`, `"image"` |
| `subrole` | The subrole | `"AXSecureTextField"` |
| `identifier` | AXIdentifier: the steadiest choice when the app sets one | `"printButton"` |
| `title` | AXTitle | `"Export"` |
| `description` | AXDescription | `"homepage"` |
| `help` | The tooltip | `"Slice plate*"` |
| `value` | The current value | `"100%"` |
| `text` | The text inside the element | `"Open Project"` |
| `window` | The title of its window | `"Untitled*"` |
| `inside` | An ancestor that must match (another match) | `{"role": "toolbar"}` |
| `parent` | The immediate parent must match (another match) | `{"role": "group"}` |
| `unnamed` | Only elements with no title or description | `true` |
| `pressable` | Only elements that can be pressed (actions include Press) | `true` |
| `nth` | For keys: which of the matches (1 first, -1 last) | `2` |

The snapshot (snapshot.txt, or `bosun-plugin snapshot <app>`) shows every element as
`role/subrole title= description= help= identifier= text= value= actions=`. Controls with no name
are marked `UNNAMED`, with the text beside them when there is some. That is usually the label.

Good matches are specific enough to hit only what you mean, and plain enough to survive an app
update: prefer `identifier`, then `role` with `title`, `description` or `help`, then
`unnamed` with `inside`. Avoid `nth` in labels.

## labels

Labels are tried in order; the first rule that matches an element wins. Put specific rules before
general ones.

```json
{ "match": { "role": "image", "unnamed": true, "inside": { "description": "homepage" } },
  "nameFrom": "nextText", "role": "button" }
```

- `name`: the name to speak, or
- `nameFrom`: where to take it from: `"nextText"` (the nearest text after it), `"previousText"`,
  `"childText"` (its own text), `"parentText"`, `"help"` (the tooltip's first sentence),
  `"description"`.
- `role` (optional): the role to speak instead of the element's own, such as `"button"` for a
  pressable image.

When the name comes from the text beside the element, TurnOver does not read that text again.

## keys

```json
{ "key": "bosun+shift+p", "description": "Prepare tab", "action": "press",
  "target": { "role": "radio button", "title": "Prepare" } }
```

- `key`: a TurnOver gesture. Modifiers: `bosun` (the user's TurnOver key: Caps Lock, or Control+Option),
  `shift`, `control`, `option`, `command`. Keys: letters, digits, `f1`…`f12`, `upArrow`,
  `downArrow`, `leftArrow`, `rightArrow`, `enter`, `escape`, `tab`, `space`, `home`, `end`,
  `pageUp`, `pageDown`, `delete`, `backspace`, and punctuation such as `/` `.` `,` `[` `]`.
  Use `bosun+` keys for plugin commands, so the application's own shortcuts still work. Check
  menus.txt for the application's shortcuts before choosing one without `bosun`.
- `description`: what it does, in a few words; spoken by input help and listed in the shortcuts list.
- `action`, one of:
  - `"press"`: press `target`.
  - `"focus"`: move the keyboard focus to `target`.
  - `"read"`: read `target` (its text, or its name and state).
  - `"menu"`: choose a menu item by path: `"menu": ["File", "Export", "Export G-code…"]`.
    Paths are in menus.txt; `*` works in each step.
  - `"keys"`: send a key combination to the application: `"keys": "command+shift+e"`.
  - `"say"`: speak `say`.
- `say` (optional with any action): spoken after it, such as `"Exported"`.

## watch

```json
{ "match": { "role": "progress indicator", "inside": { "title": "Slicing*" } }, "prefix": "Slicing" }
```

Reads the element whenever its value changes while the application is in front.
`read`: `"value"` (default) or `"text"`. `prefix`: spoken first.

## silence

```json
{ "role": "image", "unnamed": true, "inside": { "description": "banner*" } }
```

Elements that only add noise. TurnOver does not announce them on focus and leaves them out of
documents.

## Testing

The tool is inside TurnOver: `/Applications/TurnOver.app/Contents/MacOS/bosun-plugin`.

```
bosun-plugin check "<plugin folder>"          the rules against the running app, and what TurnOver will say
bosun-plugin check "<plugin folder>" --read   also web content as TurnOver reads it with the plugin
bosun-plugin snapshot <app>                   the app as it is now (after switching screens)
bosun-plugin menus <app>                      every menu path
bosun-plugin install "<plugin folder>"        install; applies the next time the app comes to the front
bosun-plugin list                             what is installed
```

`check` exits with an error and says PROBLEM for every rule that matches nothing, a key TurnOver does
not know, a target that cannot be pressed, or a missing menu item. A rule may match nothing because
its element is on another screen of the app (a tab not showing, a dialog not open); check again
with that screen showing.

## A complete example

Bambu Studio's home page has pressable images with no names; the name of each is the text
beside it.

```json
{
  "labels": [
    { "match": { "role": "image", "unnamed": true, "pressable": true, "inside": { "description": "homepage" } },
      "nameFrom": "nextText", "role": "button" }
  ],
  "keys": [
    { "key": "bosun+shift+n", "description": "New project", "action": "menu", "menu": ["File", "New Project"] }
  ]
}
```

## Sharing

A plugin is its folder. Share the folder; whoever installs it uses `bosun-plugin install`. A
catalogue with review and signing is planned (PLATFORM.md).
